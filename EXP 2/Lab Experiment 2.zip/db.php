<?php
$host='localhost';
$uname='root';
$password="";
$dbname="facebook";
$connection=mysqli_connect($host,$uname,$password,$dbname);
?>