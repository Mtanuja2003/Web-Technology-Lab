function showLogin() {
    document.getElementById("login_dialog").showModal();
}

function closeLogin() {
    document.getElementById("login_dialog").close();
}

function showSignup() {
    document.getElementById("signup_dialog").showModal();
}

function closeSignup() {
    document.getElementById("signup_dialog").close();
}